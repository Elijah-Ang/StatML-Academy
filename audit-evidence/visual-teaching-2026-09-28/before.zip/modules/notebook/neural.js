import {
  makeLab,
  fmt,
  palette,
  extent,
  linspace,
  plotLine,
  bars,
  flow,
} from "./lab.js";
import {
  classificationData,
  splitRows,
  networkInitial,
  networkForward,
  networkStep,
  networkLoss,
  activation,
  filters,
  imagePatch,
  convolve,
  attention,
  mean,
  sum,
  sigmoid,
} from "./science.js";
export function create(host, slug) {
  const initialModel = networkInitial(7),
    initial = {
      x: 0.8,
      z: 0.4,
      label: 1,
      weight: initialModel.hidden[0].w[0],
      activation: "tanh",
      rate: 0.2,
      decay: 0,
      phase: 0,
      architecture: "cnn",
      filter: "vertical",
      window: 0,
      token: 1,
      dropout: "evaluation",
      transfer: "head",
      contract: "valid",
      task: "classification",
    };
  const controls = [
    { key: "x", label: "Input x₁", min: -2, max: 2, step: 0.05 },
    { key: "z", label: "Input x₂", min: -2, max: 2, step: 0.05 },
    {
      key: "label",
      label: "Inspected true class",
      options: [
        ["1", "Positive: 1"],
        ["0", "Negative: 0"],
      ],
    },
    {
      key: "weight",
      label: "Manual first weight (restarts run)",
      min: -2,
      max: 2,
      step: 0.01,
    },
    {
      key: "activation",
      label: "Hidden activation (restarts run)",
      options: [
        ["tanh", "Tanh"],
        ["relu", "ReLU"],
        ["sigmoid", "Sigmoid"],
      ],
    },
    { key: "rate", label: "Learning rate", min: 0.02, max: 1, step: 0.02 },
    { key: "decay", label: "Weight decay", min: 0, max: 0.3, step: 0.01 },
    {
      key: "architecture",
      label: "Architecture mechanism",
      options: [
        ["cnn", "CNN: trace a 3×3 filter"],
        ["rnn", "RNN: trace a scalar state"],
        ["attention", "Attention: trace one query"],
      ],
    },
    {
      key: "filter",
      label: "Convolution filter",
      options: [
        ["vertical", "Vertical edge"],
        ["horizontal", "Horizontal edge"],
      ],
    },
    {
      key: "window",
      label: "Convolution window (0–8)",
      min: 0,
      max: 8,
      step: 1,
    },
    {
      key: "token",
      label: "Query token / recurrent step",
      min: 0,
      max: 3,
      step: 1,
    },
    {
      key: "dropout",
      label: "Dropout demonstration",
      options: [
        ["evaluation", "Evaluation: all units"],
        ["training", "Training: fixed one-third mask"],
      ],
    },
    {
      key: "transfer",
      label: "Trainable transfer regions",
      options: [
        ["head", "New head only"],
        ["fine", "Head and last backbone block"],
      ],
    },
    {
      key: "contract",
      label: "Incoming input contract",
      options: [
        ["valid", "Correct numeric inputs"],
        ["swapped", "Swap input order"],
        ["missing", "Missing second input"],
      ],
    },
    ...(slug === "deep-learning"
      ? [
          {
            key: "task",
            label: "Output task",
            options: [
              ["classification", "Classification"],
              ["detection", "Detection"],
              ["segmentation", "Segmentation"],
            ],
          },
        ]
      : []),
  ];
  const L = makeLab(host, slug, initial, controls),
    split = splitRows(classificationData(74, "rings", 80));
  let model = structuredClone(initialModel),
    steps = 0,
    history = [],
    trace = [],
    last = null,
    signature = "";
  const loss = () => ({
    step: steps,
    train: networkLoss(model, split.train, L.state.activation),
    validation: networkLoss(model, split.validation, L.state.activation),
  });
  const checkpoint = () =>
    history.push({
      model: structuredClone(model),
      steps,
      trace: structuredClone(trace),
      last: structuredClone(last),
      phase: L.state.phase,
    });
  function resetRun() {
    model = networkInitial(7);
    model.hidden[0].w[0] = L.state.weight;
    steps = 0;
    trace = [loss()];
    history = [];
    last = null;
    L.state.phase = 0;
    signature = L.state.weight + "|" + L.state.activation;
  }
  function update() {
    const result = networkStep(model, split.train, {
      rate: L.state.rate,
      decay: L.state.decay,
      kind: L.state.activation,
    });
    last = {
      before: structuredClone(model),
      gradient: result.gradient,
      after: structuredClone(result.model),
    };
    model = result.model;
    steps++;
    trace.push(loss());
  }
  L.onReset = resetRun;
  L.action("cycle-next", "Next: loss", () => {
    checkpoint();
    const phase = (L.state.phase + 1) % 4;
    if (phase === 3) update();
    L.update({ phase }, true);
  });
  L.action("cycle-back", "Rewind last action", () => {
    const old = history.pop();
    if (!old) return;
    model = old.model;
    steps = old.steps;
    trace = old.trace;
    last = old.last;
    L.update({ phase: old.phase }, true);
  });
  L.action("train-batch", "Train 20 more updates", () => {
    checkpoint();
    for (let i = 0; i < 20; i++) update();
    L.update({ phase: 3 }, true);
  });
  return L.init((animate = false) => {
    const st = L.state;
    if (signature !== st.weight + "|" + st.activation) resetRun();
    const scene = L.scene,
      q = { x: st.x, z: st.z, y: +st.label },
      mask =
        scene === "regularization" && st.dropout === "training"
          ? [0, 1.5, 1.5]
          : [1, 1, 1],
      f = networkForward(model, q, st.activation, mask),
      gradient = networkStep(model, split.train, {
        rate: 0,
        kind: st.activation,
      }).gradient,
      phase = ["Forward", "Loss", "Backward", "Update"][st.phase],
      phaseNext = ["loss", "gradients", "update", "forward"][st.phase],
      rowLoss = -(q.y
        ? Math.log(Math.max(f.p, 1e-12))
        : Math.log(Math.max(1 - f.p, 1e-12)));
    document.getElementById("cycle-next").textContent = "Next: " + phaseNext;
    document.getElementById("cycle-back").disabled = !history.length;
    const convR = Math.floor(st.window / 3),
      convC = st.window % 3,
      kernel = filters[st.filter],
      conv = convolve(kernel, convR, convC),
      att = attention(st.token),
      tokens = ["the", "cat", "sat", "here"],
      rnnInputs = [0.2, 1, -0.4, 0.8],
      rnn = [];
    let h = 0;
    rnnInputs.forEach((x, i) => {
      const before = h;
      h = Math.tanh(0.7 * h + 0.5 * x);
      rnn.push({ x, before, h, i });
    });
    const validation = split.validation.map((r) => ({
        ...r,
        p: networkForward(model, r, st.activation).p,
      })),
      counts = { tp: 0, fp: 0, fn: 0, tn: 0 };
    validation.forEach(
      (r) =>
        counts[r.y ? (r.p >= 0.5 ? "tp" : "fn") : r.p >= 0.5 ? "fp" : "tn"]++,
    );
    L.data = {
      model,
      steps,
      trace,
      last,
      gradient,
      forward: f,
      mask,
      split,
      counts,
      convolution: conv,
      attention: att,
      rnn,
      phase,
    };
    L.metrics([
      ["Updates completed", steps],
      ["Inspected P(class 1)", fmt(f.p, 4)],
      [
        "Validation log loss",
        fmt(networkLoss(model, split.validation, st.activation), 4),
      ],
    ]);
    L.legend([
      ["Inputs / values", palette[0]],
      ["Hidden computation", palette[2]],
      ["Loss / correction", palette[1]],
    ]);
    let receipt = [
      [
        "Neuron 1 input products",
        fmt(model.hidden[0].w[0] * q.x, 4) +
          " + " +
          fmt(model.hidden[0].w[1] * q.z, 4),
      ],
      ["Neuron 1 bias", fmt(model.hidden[0].b, 4)],
      ["Neuron 1 sum → activation", fmt(f.z[0], 4) + " → " + fmt(f.a[0], 4)],
      ["Output score → probability", fmt(f.score, 4) + " → " + fmt(f.p, 4)],
      ["Inspected row loss", fmt(rowLoss, 4)],
    ];
    let notice =
      "Computed 2→3→1 binary teaching network. 48 training rows receive gradients; 16 validation rows only measure loss; 16 final-test rows remain sealed. The input sliders inspect a query and do not add it to training. This is not a trained image recognizer.";
    if (["cycle", "backward", "update"].includes(scene)) {
      const showLast =
          st.phase === 3 && last && (scene === "cycle" || scene === "update"),
        g = showLast ? last.gradient : gradient,
        before = showLast ? last.before : model,
        after = showLast
          ? last.after
          : networkStep(model, split.train, {
              rate: st.rate,
              decay: st.decay,
              kind: st.activation,
            }).model;
      receipt = [
        ["Cycle phase", phase],
        ["Gradient ∂L/∂w₁₁", fmt(g.hidden[0].w[0], 6)],
        ["Before w₁₁", fmt(before.hidden[0].w[0], 6)],
        ["Learning rate", fmt(st.rate, 3)],
        ["After / proposed w₁₁", fmt(after.hidden[0].w[0], 6)],
        [
          "Update rule",
          "w − η(gradient + decay × w); all gradients use the same old parameter snapshot.",
        ],
      ];
    }
    if (scene === "training" || scene === "settings")
      receipt = [
        ["Completed training updates", steps],
        [
          "Training BCE",
          fmt(networkLoss(model, split.train, st.activation), 5),
        ],
        [
          "Validation BCE",
          fmt(networkLoss(model, split.validation, st.activation), 5),
        ],
        [
          "Best stored validation step",
          trace.reduce((a, b) => (b.validation < a.validation ? b : a)).step,
        ],
        [
          "Selection",
          "These are development curves; no final-test performance is used.",
        ],
      ];
    if (scene === "evaluation" || scene === "errors")
      receipt = [
        ...Object.entries(counts).map(([k, v]) => [
          "Validation " + k.toUpperCase(),
          v,
        ]),
        ["Inspected query label / probability", q.y + " / " + fmt(f.p, 4)],
        ["Query BCE", fmt(rowLoss, 4)],
        [
          "Final test",
          "Sealed: these are validation counts, not final-test evidence.",
        ],
      ];
    if (scene === "regularization")
      receipt = [
        ["Mask", mask.join(", ")],
        [
          "Convention",
          "Drop one of three units; scale retained activations by 1/(2/3) during training.",
        ],
        ["Evaluation", "Use all units with no mask scaling."],
        [
          "Scope",
          "Fixed-mask forward demonstration. The train button uses the full network plus the selected weight decay, not stochastic dropout.",
        ],
      ];
    if (scene === "architecture") {
      if (st.architecture === "cnn")
        receipt = [
          ["Input shape", "5 × 5, one channel"],
          ["Filter / stride / padding", "3 × 3 / 1 / valid"],
          ["Output shape", "3 × 3"],
          ["Selected window", "row " + convR + ", column " + convC],
          ["Sum of nine products", fmt(conv, 3)],
          [
            "Operation",
            "Cross-correlation, as commonly called convolution in CNN layers.",
          ],
        ];
      if (st.architecture === "attention")
        receipt = [
          ["Query token", tokens[st.token]],
          ["Scaled QK scores", att.scores.map((x) => fmt(x, 3)).join(", ")],
          ["Softmax weights", att.weights.map((x) => fmt(x, 3)).join(", ")],
          ["Sum of weights", fmt(sum(att.weights), 6)],
          [
            "Context = Σ weight × V",
            att.context.map((x) => fmt(x, 4)).join(", "),
          ],
          [
            "Scope",
            "One computed attention head with fixed illustrative Q, K and V vectors.",
          ],
        ];
      if (st.architecture === "rnn") {
        const r = rnn[st.token];
        receipt = [
          ["Step", st.token + 1],
          ["Previous state", fmt(r.before, 5)],
          ["Input", r.x],
          ["Update", "tanh(0.7 × previous + 0.5 × input)"],
          ["New state", fmt(r.h, 5)],
        ];
      }
    }
    if (scene === "transfer")
      receipt = [
        ["Backbone blocks 1–2", "Frozen"],
        ["Backbone block 3", st.transfer === "fine" ? "Trainable" : "Frozen"],
        ["New task head", "Trainable"],
        [
          "Scope",
          "Architecture schematic; no pretrained model or transfer accuracy is fabricated.",
        ],
      ];
    if (scene === "tensor")
      receipt = [
        ["One example", "5 × 5 × 1 = 25 numerical entries"],
        ["Batch of 8", "8 × 5 × 5 × 1 = 200 entries"],
        ["Convention", "Batch, height, width, channels"],
        [
          "Meaning",
          "Array organization, not distances between learned features.",
        ],
      ];
    if (scene === "task")
      receipt = [
        ["Task", st.task],
        [
          "Required output",
          st.task === "classification"
            ? "A class probability vector"
            : st.task === "detection"
              ? "Object boxes with labels and confidence"
              : "A class distribution at each pixel",
        ],
        [
          "Required supervision",
          st.task === "classification"
            ? "Image-level labels"
            : st.task === "detection"
              ? "Annotated boxes"
              : "Pixel-level labels",
        ],
        [
          "Scope",
          "Illustrative output contract; no image model inference is performed.",
        ],
      ];
    if (scene === "contract")
      receipt =
        st.contract === "missing"
          ? [
              ["Input rejected", "Second numerical input is missing."],
              ["Repair", "Supply x₁ and x₂ in the saved order and units."],
            ]
          : [
              [
                "Input order",
                st.contract === "swapped" ? "Incorrectly swapped" : "Correct",
              ],
              [
                "Resulting probability",
                fmt(
                  networkForward(
                    model,
                    st.contract === "swapped" ? { x: q.z, z: q.x } : q,
                    st.activation,
                  ).p,
                  5,
                ),
              ],
              [
                "Saved package",
                "Feature order, transforms, architecture, weights, decision threshold, versions.",
              ],
            ];
    if (scene === "architecture") {
      L.metrics(
        st.architecture === "cnn"
          ? [
              ["Window sum", fmt(conv, 0)],
              ["Output shape", "3 × 3"],
              ["Filter entries", 9],
            ]
          : st.architecture === "attention"
            ? [
                ["Query", tokens[st.token]],
                ["Weight sum", fmt(sum(att.weights), 3)],
                ["Context dimension", 2],
              ]
            : [
                ["Step", st.token + 1],
                ["Previous state", fmt(rnn[st.token].before, 3)],
                ["New state", fmt(rnn[st.token].h, 3)],
              ],
      );
      L.legend(
        st.architecture === "cnn"
          ? [
              ["Input values", palette[0]],
              ["Selected window", palette[1]],
              ["Output sum", palette[2]],
            ]
          : st.architecture === "attention"
            ? [["Attention weights: sum to one", palette[0]]]
            : [["Sequential hidden state", palette[2]]],
      );
    }
    if (scene === "tensor")
      L.metrics([
        ["Entries per example", 25],
        ["Batch size", 8],
        ["Entries per batch", 200],
      ]);
    if (scene === "transfer")
      L.metrics([
        ["New head", "Trainable"],
        ["Backbone", st.transfer === "fine" ? "Partly trainable" : "Frozen"],
        ["Illustration", "Schematic"],
      ]);
    if (scene === "task")
      L.metrics([
        ["Task", st.task],
        [
          "Output",
          st.task === "classification"
            ? "Class vector"
            : st.task === "detection"
              ? "Boxes"
              : "Pixel labels",
        ],
        ["Illustration", "Contract"],
      ]);
    if (scene === "contract")
      L.metrics([
        [
          "Input status",
          st.contract === "valid"
            ? "Valid"
            : st.contract === "missing"
              ? "Rejected"
              : "Order changed",
        ],
        ["Required inputs", 2],
        ["Saved threshold", "0.5"],
      ]);
    if (scene === "backward" || (scene === "cycle" && st.phase === 2))
      L.legend([
        ["Positive gradient", palette[1]],
        ["Negative gradient", palette[0]],
        ["Hidden activation", palette[2]],
      ]);
    L.receipt(L.table(["Follow the computation", "Value"], receipt));
    L.note(notice);
    // Keep the control set focused without destroying its DOM or entered values.
    const visible = new Set([
      "view",
      ...([
        "pipeline",
        "hierarchy",
        "shortcut",
        "task",
        "tensor",
        "architecture",
        "transfer",
      ].includes(scene)
        ? []
        : ["x", "z", "label"]),
      ...(["neuron", "network", "forward", "activation"].includes(scene)
        ? ["weight", "activation"]
        : []),
      ...(["cycle", "training", "settings", "update", "backward"].includes(
        scene,
      )
        ? ["rate", "decay"]
        : []),
      ...(scene === "architecture"
        ? [
            "architecture",
            ...(st.architecture === "cnn" ? ["filter", "window"] : ["token"]),
          ]
        : []),
      ...(scene === "regularization" ? ["dropout"] : []),
      ...(scene === "transfer" ? ["transfer"] : []),
      ...(scene === "contract" ? ["contract"] : []),
      ...(scene === "task" ? ["task"] : []),
    ]);
    controls.forEach((c) => {
      document.getElementById(c.key).closest("label").hidden = !visible.has(
        c.key,
      );
    });
    document.getElementById("lab-actions").hidden = ![
      "cycle",
      "training",
      "settings",
      "update",
      "backward",
      "network",
      "forward",
      "loss",
    ].includes(scene);
    L.draw((s, P) => {
      const { w } = s.begin(310);
      if (
        [
          "pipeline",
          "contract",
          "hierarchy",
          "shortcut",
          "transfer",
          "task",
          "inputs",
        ].includes(scene)
      ) {
        const steps =
          scene === "pipeline"
            ? [
                "Split original people / groups / time",
                "Fit preprocessing on training only",
                "Train: update network parameters",
                "Validation: choose settings and checkpoint",
                "Test: evaluate a frozen procedure",
              ]
            : scene === "transfer"
              ? [
                  "Backbone blocks 1–2: FROZEN",
                  "Backbone block 3: " +
                    (st.transfer === "fine" ? "TRAINABLE" : "FROZEN"),
                  "New task head: TRAINABLE",
                  "Validate for domain mismatch",
                ]
              : scene === "contract"
                ? [
                    "Check input shape, order, and units",
                    st.contract === "missing"
                      ? "STOP: required input missing"
                      : st.contract === "swapped"
                        ? "WARNING: inputs swapped"
                        : "Apply saved transforms",
                    "Run the saved network",
                    "Apply saved action rule and monitor",
                  ]
                : scene === "shortcut"
                  ? [
                      "Training photos share a background clue",
                      "Network may use the easy shortcut",
                      "Hold out sites / people / collection batches",
                      "Check whether the intended pattern transfers",
                    ]
                  : scene === "task"
                    ? [
                        "Input: one example",
                        st.task === "classification"
                          ? "Output: a class distribution"
                          : st.task === "detection"
                            ? "Output: boxes and class labels"
                            : "Output: a class for each pixel",
                        "Match annotation to the output contract",
                        "Choose metrics for the real decision",
                      ]
                    : scene === "inputs"
                      ? [
                          "Row: x₁ = " + fmt(q.x, 2) + ", x₂ = " + fmt(q.z, 2),
                          "True target: " + q.y + " (training feedback only)",
                          "Network receives the two inputs",
                          "Output: estimated class-1 probability",
                        ]
                      : [
                          "Inputs: numerical measurements",
                          "Layer 1: combinations of inputs",
                          "Layer 2: combinations of representations",
                          "Output: a task-specific prediction",
                        ];
        flow(
          s,
          P,
          steps,
          scene === "contract" && st.contract === "missing"
            ? 1
            : L.index % steps.length,
        );
      } else if (
        (scene === "architecture" && st.architecture === "cnn") ||
        scene === "tensor"
      ) {
        const cell = Math.min(37, (w - 72) / 8),
          total = 8 * cell + 24,
          x0 = Math.max(15, (w - total) / 2),
          y0 = 48;
        imagePatch.forEach((r, i) =>
          r.forEach((v, j) => {
            s.rect(
              "pixel" + i + j,
              x0 + j * cell,
              y0 + i * cell,
              cell - 2,
              cell - 2,
              v ? palette[0] + "a0" : "#e9ebdf",
              { stroke: "#c7ccbe" },
            );
            s.text(
              "pixelv" + i + j,
              x0 + j * cell + cell / 2,
              y0 + i * cell + cell * 0.65,
              String(v),
              { "font-size": 12, "text-anchor": "middle" },
            );
          }),
        );
        s.text("input-shape", x0, 29, "5 × 5 × 1 input", { "font-size": 16 });
        if (scene === "architecture") {
          const p = P("window", x0 + convC * cell, y0 + convR * cell);
          s.rect("window", p[0] - 2, p[1] - 2, cell * 3, cell * 3, "none", {
            stroke: palette[1],
            "stroke-width": 3,
          });
          const ox = x0 + cell * 5 + 24,
            oc = cell;
          for (let r = 0; r < 3; r++)
            for (let c = 0; c < 3; c++) {
              const v = convolve(kernel, r, c);
              s.rect(
                "out" + r + c,
                ox + c * oc,
                78 + r * oc,
                oc - 2,
                oc - 2,
                r === convR && c === convC ? palette[2] + "70" : "#e6eadf",
              );
              s.text(
                "outv" + r + c,
                ox + c * oc + oc / 2,
                78 + r * oc + oc * 0.67,
                fmt(v, 0),
                { "font-size": 12, "text-anchor": "middle" },
              );
            }
          s.text("output-shape", ox, 60, "3 × 3 output", { "font-size": 13 });
          s.text(
            "kernel",
            15,
            260,
            "Filter rows: " +
              kernel.map((r) => "[" + r.join(", ") + "]").join(" "),
            { "font-size": Math.min(14, (w - 30) / 35) },
          );
          s.text("conv-result", 15, 287, "Selected sum = " + fmt(conv, 0), {
            "font-size": 19,
          });
        } else flowTensorCaption(s, w);
      } else if (scene === "architecture" && st.architecture === "attention") {
        bars(
          s,
          P,
          att.weights.map((value, i) => ({
            label: tokens[i],
            value,
            color: palette[i],
          })),
          { domain: 1 },
        );
        s.text(
          "query-token",
          14,
          22,
          "Query: " + tokens[st.token] + " · normalized attention",
          { "font-size": 16 },
        );
      } else if (scene === "architecture" && st.architecture === "rnn") {
        flow(
          s,
          P,
          rnn.map(
            (r) =>
              "Step " + (r.i + 1) + ": h = tanh(0.7h + 0.5x) = " + fmt(r.h, 3),
          ),
          st.token,
        );
      } else if (scene === "training" || scene === "settings") {
        const max = Math.max(
            ...trace.flatMap((r) => [r.train, r.validation]),
            0.7,
          ),
          a = s.axes(
            [0, Math.max(1, steps)],
            [0, max * 1.1],
            "Parameter update",
            "Binary log loss",
          );
        ["train", "validation"].forEach((k, i) => {
          plotLine(
            s,
            P,
            "loss" + k,
            trace.map((r) => [a.x(r.step), a.y(r[k])]),
            palette[i],
            2.5,
          );
          if (trace.length === 1)
            s.circle("initial" + k, a.x(0), a.y(trace[0][k]), 5, palette[i]);
        });
        s.text("training-legend", 48, 18, "Blue: train · red: validation", {
          "font-size": 14,
        });
      } else if (scene === "evaluation") {
        bars(
          s,
          P,
          Object.entries(counts).map(([k, value], i) => ({
            label: k.toUpperCase(),
            value,
            color: palette[i],
          })),
        );
      } else if (scene === "activation") {
        const a = s.axes(
            [-4, 4],
            st.activation === "tanh"
              ? [-1.1, 1.1]
              : [0, st.activation === "relu" ? 4 : 1.1],
            "Weighted sum",
            "Activation",
          ),
          xs = linspace(-4, 4);
        plotLine(
          s,
          P,
          "activation",
          xs.map((x) => [a.x(x), a.y(activation(x, st.activation))]),
          palette[2],
          2.5,
        );
        const z = Math.max(-4, Math.min(4, f.z[0])),
          p = P("neuron", a.x(z), a.y(activation(z, st.activation)));
        s.circle("neuron", ...p, 7, palette[1]);
      } else if (scene === "loss") {
        const a = s.axes(
            [0.01, 0.99],
            [0, 5],
            "Probability of class 1",
            "Binary cross-entropy",
          ),
          xs = linspace(0.01, 0.99);
        plotLine(
          s,
          P,
          "loss",
          xs.map((p) => [a.x(p), a.y(-(q.y ? Math.log(p) : Math.log(1 - p)))]),
          palette[1],
          2.5,
        );
        const p = P(
          "current",
          a.x(Math.max(0.01, Math.min(0.99, f.p))),
          a.y(Math.min(5, rowLoss)),
        );
        s.circle("current", ...p, 7, palette[0]);
      } else {
        const xs = [38, w * 0.49, w - 42],
          iy = [112, 207],
          hy = [65, 151, 237],
          oy = 151,
          back = scene === "backward" || (scene === "cycle" && st.phase === 2),
          drop = scene === "regularization" && st.dropout === "training";
        for (let i = 0; i < 2; i++)
          for (let j = 0; j < 3; j++) {
            const value = model.hidden[j].w[i],
              grad = gradient.hidden[j].w[i];
            s.line(
              "edge" + i + j,
              xs[0],
              iy[i],
              xs[1],
              hy[j],
              drop && j === 0
                ? "#c4c6ba"
                : back
                  ? grad >= 0
                    ? palette[1]
                    : palette[0]
                  : value >= 0
                    ? palette[2]
                    : palette[1],
              Math.min(5, 1 + Math.abs(back ? grad * 5 : value)),
              drop && j === 0 ? "4 4" : null,
            );
          }
        for (let j = 0; j < 3; j++) {
          const value = back ? gradient.out[j] : model.out[j];
          s.line(
            "output-edge" + j,
            xs[1],
            hy[j],
            xs[2],
            oy,
            drop && j === 0
              ? "#c4c6ba"
              : back
                ? value >= 0
                  ? palette[1]
                  : palette[0]
                : value >= 0
                  ? palette[2]
                  : palette[1],
            Math.min(5, 1 + Math.abs(back ? value * 5 : value)),
            drop && j === 0 ? "4 4" : null,
          );
        }
        [q.x, q.z].forEach((v, i) => {
          const p = P("input" + i, xs[0], iy[i]);
          s.circle("input" + i, ...p, 23, "#e4edf0", {
            stroke: palette[0],
            "stroke-width": 2,
          });
          s.text("inputv" + i, p[0], p[1] + 5, fmt(v, 2), {
            "text-anchor": "middle",
            "font-size": 14,
          });
          s.text("input-name" + i, p[0], p[1] - 33, "x" + (i + 1), {
            "text-anchor": "middle",
            "font-size": 16,
          });
        });
        f.a.forEach((v, i) => {
          const p = P("hidden" + i, xs[1], hy[i]);
          s.circle(
            "hidden" + i,
            ...p,
            26,
            drop && i === 0 ? "#e8e9df" : "#e5eddf",
            { stroke: palette[2], "stroke-width": 2 },
          );
          s.text(
            "hiddenv" + i,
            p[0],
            p[1] + 5,
            drop && i === 0 ? "masked" : fmt(f.used[i], 3),
            { "text-anchor": "middle", "font-size": 13 },
          );
        });
        const p = P("output", xs[2], oy);
        s.circle("output", ...p, 27, "#f2e7d4", {
          stroke: palette[3],
          "stroke-width": 2,
        });
        s.text("outputv", p[0], p[1] + 5, fmt(f.p, 3), {
          "text-anchor": "middle",
          "font-size": 14,
        });
        s.text("out-name", p[0], p[1] - 40, "P(1)", {
          "text-anchor": "middle",
          "font-size": 16,
        });
        s.text(
          "network-title",
          14,
          22,
          scene === "cycle"
            ? "Cycle phase: " + phase
            : back
              ? "Edges: gradient signs"
              : "A computed 2 → 3 → 1 network",
          { "font-size": 16 },
        );
        s.text(
          "network-footer",
          14,
          294,
          back
            ? "Gradients ready · update changes weights"
            : "Green: positive weight · red: negative weight",
          { "font-size": 12 },
        );
      }
      s.end(receipt.map((r) => r.join(": ")).join(". "));
    }, animate);
  });
}
function flowTensorCaption(s, w) {
  s.text("tensor-count", 15, 254, "One example: 25 values", {
    "font-size": 19,
  });
  s.text("batch-count", 15, 283, "Batch of 8: 200 values", { "font-size": 19 });
}
