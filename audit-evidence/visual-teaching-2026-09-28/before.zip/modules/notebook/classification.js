import {
  makeLab,
  fmt,
  palette,
  extent,
  linspace,
  plotLine,
  bars,
  flow,
} from "./lab.js";
import {
  classificationData,
  splitRows,
  logisticFit,
  knnFit,
  discriminantFit,
  oneRuleFit,
  svmFit,
  sigmoid,
  mean,
  sum,
  logLoss,
  clamp,
} from "./science.js";
const matrix = (rows, predict, threshold) => {
  const c = { tp: 0, fp: 0, fn: 0, tn: 0 };
  rows.forEach(
    (r) =>
      c[
        r.y
          ? predict(r) >= threshold
            ? "tp"
            : "fn"
          : predict(r) >= threshold
            ? "fp"
            : "tn"
      ]++,
  );
  return c;
};
export function create(host, slug) {
  const svm = slug === "support-vector-machine",
    knn = slug === "knn",
    qda = slug === "qda",
    lda = slug === "lda",
    one = slug === "one-r",
    imb = slug === "imbalanced-classification";
  const initial = {
    scenario: qda ? "unequal" : "clouds",
    threshold: svm ? 0 : 0.5,
    k: 5,
    scaling: "yes",
    weighted: "no",
    lambda: 0.02,
    shrink: 0,
    C: 1,
    kernel: "linear",
    gamma: 0.8,
    query: 0,
    second: 0,
    selected: "C1",
    feature: "auto",
    prevalence: 1,
    seed: 42,
  };
  const controls = [
    ...(!imb
      ? [
          {
            key: "scenario",
            label: "Class pattern",
            options: [
              ["clouds", "Overlapping clouds"],
              ["unequal", "Unequal covariance"],
              ["rings", "Inner and outer rings"],
            ],
          },
          { key: "query", label: "Query x", min: -2.5, max: 2.5, step: 0.05 },
          { key: "second", label: "Query z", min: -2.5, max: 2.5, step: 0.05 },
        ]
      : [
          {
            key: "prevalence",
            label: "Positive prevalence (%)",
            min: 1,
            max: 40,
            step: 1,
          },
        ]),
    {
      key: "threshold",
      label: svm ? "Decision score threshold" : "Decision threshold",
      min: svm ? -1 : 0,
      max: 1,
      step: 0.01,
    },
    ...(knn
      ? [
          { key: "k", label: "Neighbors K", min: 1, max: 21, step: 2 },
          {
            key: "scaling",
            label: "Training SD scaling",
            options: [
              ["yes", "On"],
              ["no", "Off"],
            ],
          },
          {
            key: "weighted",
            label: "Vote weights",
            options: [
              ["no", "Uniform"],
              ["yes", "Inverse distance"],
            ],
          },
        ]
      : []),
    ...(qda
      ? [
          {
            key: "shrink",
            label: "Shrink toward pooled covariance",
            min: 0,
            max: 1,
            step: 0.05,
          },
        ]
      : []),
    ...(svm
      ? [
          {
            key: "C",
            label: "Violation penalty C",
            min: 0.1,
            max: 5,
            step: 0.1,
          },
          {
            key: "kernel",
            label: "Kernel",
            options: [
              ["linear", "Linear"],
              ["rbf", "RBF"],
            ],
          },
          {
            key: "gamma",
            label: "RBF gamma (scaled inputs)",
            min: 0.1,
            max: 3,
            step: 0.1,
          },
        ]
      : []),
    ...(one
      ? [
          {
            key: "feature",
            label: "Rule feature",
            options: [
              ["auto", "Choose on training error"],
              ["x", "Input x"],
              ["z", "Input z"],
            ],
          },
        ]
      : []),
    ...(!svm && !knn && !qda && !lda && !one && !imb
      ? [{ key: "lambda", label: "L2 penalty", min: 0, max: 1, step: 0.02 }]
      : []),
  ];
  const L = makeLab(host, slug, initial, controls);
  let data,
    key = "",
    sealed = null;
  function compute() {
    const st = L.state,
      k = JSON.stringify([
        st.scenario,
        st.k,
        st.scaling,
        st.weighted,
        st.lambda,
        st.shrink,
        st.C,
        st.kernel,
        st.gamma,
        st.feature,
        st.seed,
      ]);
    if (data && key === k) return data;
    key = k;
    const split = splitRows(classificationData(st.seed, st.scenario)),
      train = split.train;
    let fit, score;
    if (knn)
      fit = knnFit(train, st.k, st.scaling === "yes", st.weighted === "yes");
    else if (lda || qda) fit = discriminantFit(train, qda, st.shrink);
    else if (one) fit = oneRuleFit(train, st.feature);
    else if (svm) {
      const mx = mean(train.map((r) => r.x)),
        mz = mean(train.map((r) => r.z)),
        sx = Math.sqrt(mean(train.map((r) => (r.x - mx) ** 2))) || 1,
        sz = Math.sqrt(mean(train.map((r) => (r.z - mz) ** 2))) || 1,
        transform = (r) => ({ ...r, x: (r.x - mx) / sx, z: (r.z - mz) / sz });
      fit = svmFit(train.map(transform), st.C, st.kernel, st.gamma);
      const raw = fit.score;
      fit.score = (r) => raw(transform(r));
      fit.predict = (r) => (fit.score(r) >= 0 ? 1 : 0);
      fit.scaler = { mx, mz, sx, sz };
      fit.transform = transform;
    } else fit = logisticFit(train, 350, 0.2, st.lambda);
    score = svm ? fit.score : fit.predict;
    const grid = Array.from({ length: 24 * 20 }, (_, i) => {
      const x = -3 + (6 * (i % 24)) / 23,
        z = -3 + (6 * Math.floor(i / 24)) / 19;
      return { x, z, score: score({ x, z }) };
    });
    const predictions = split.validation.map((r) => ({
      ...r,
      score: score(r),
    }));
    const thresholds = [
        Infinity,
        ...predictions.map((r) => r.score).sort((a, b) => b - a),
        -Infinity,
      ],
      roc = thresholds.map((t) => {
        const c = matrix(split.validation, score, t);
        return { x: c.fp / (c.fp + c.tn), y: c.tp / (c.tp + c.fn) };
      });
    return (data = { split, fit, score, grid, predictions, roc });
  }
  function unlock() {
    sealed = null;
    key = "";
    L.disable(
      [...controls.map((c) => c.key), "new-data", "reveal-test"],
      false,
    );
    setTextSafe("final-result", "");
  }
  L.onReset = unlock;
  if (!imb)
    L.action("new-data", "Draw a new development example", () => {
      if (!sealed) L.update({ seed: L.state.seed + 1 });
    });
  const finalButton = L.action(
    "reveal-test",
    "Lock choices & reveal final test",
    () => {
      if (sealed) return;
      const d = compute();
      sealed = {
        threshold: L.state.threshold,
        configuration: structuredClone(L.state),
        ids: d.split.test.map((r) => r.id),
        counts: matrix(d.split.test, d.score, L.state.threshold),
      };
      L.disable(
        [...controls.map((c) => c.key), "new-data", "reveal-test"],
        true,
      );
      L.update({ view: "final" }, false);
    },
  );
  finalButton.hidden = slug !== "logistic-regression";
  L.surface.onAction = (id) => {
    const r = compute().split.train.find((r) => r.id === id);
    if (r && !sealed) L.update({ query: r.x, second: r.z, selected: id });
  };
  return L.init((animate = false) => {
    const st = L.state,
      d = compute(),
      scene = L.scene,
      q = { x: st.query, z: st.second },
      score = d.score(q),
      c = imb
        ? (() => {
            const n = 10000,
              pos = Math.round((n * st.prevalence) / 100),
              sens = (1 - st.threshold) ** (Math.log(0.9) / Math.log(0.5)),
              fpr = (1 - st.threshold) ** (Math.log(0.05) / Math.log(0.5)),
              tp = Math.round(pos * sens),
              fp = Math.round((n - pos) * fpr);
            return { tp, fn: pos - tp, fp, tn: n - pos - fp };
          })()
        : matrix(d.split.validation, d.score, st.threshold);
    const precision = c.tp + c.fp ? c.tp / (c.tp + c.fp) : null,
      recall = c.tp / (c.tp + c.fn);
    L.data = { ...d, counts: c, sealed };
    L.metrics([
      [
        "Validation / scenario accuracy",
        fmt(((c.tp + c.tn) / (c.tp + c.tn + c.fp + c.fn)) * 100, 1) + "%",
      ],
      ["Recall", fmt(recall * 100, 1) + "%"],
      [
        "Precision",
        precision == null ? "Undefined" : fmt(precision * 100, 1) + "%",
      ],
    ]);
    L.legend([
      ["Class 0", palette[0]],
      ["Class 1", palette[1]],
      ["Query", palette[3]],
    ]);
    let receipt = [
      ["Query inputs", "x " + fmt(q.x, 2) + ", z " + fmt(q.z, 2)],
      [svm ? "Signed score" : "Model class-1 fraction", fmt(score, 4)],
      [
        "Decision at " + fmt(st.threshold, 2),
        score >= st.threshold ? "Class 1" : "Class 0",
      ],
      [
        "Validation counts",
        "TP " + c.tp + " · FP " + c.fp + " · FN " + c.fn + " · TN " + c.tn,
      ],
    ];
    let notice = imb
      ? "Scenario model, not measured model performance: 10,000 cases. At threshold 0.5, assumed sensitivity is 90% and false-positive rate 5%. Threshold response curves are explicit illustrative assumptions."
      : "Computed teaching dataset: 48 training, 16 validation, 16 sealed final-test rows. All fitted parameters and scales use training only. The surface shows model decisions, not ground truth.";
    if (knn) {
      const neighbors = d.fit.neighbors(q);
      receipt = [
        [
          "Training scales",
          "SD x " + fmt(d.fit.sx, 3) + " · SD z " + fmt(d.fit.sz, 3),
        ],
        ...neighbors
          .slice(0, 7)
          .map((r) => [
            r.id + " · class " + r.y,
            "distance " + fmt(r.distance, 4),
          ]),
        ["Vote", fmt(score, 4) + " class-1 fraction; " + st.k + " neighbors"],
      ];
      if (st.k > 7)
        receipt.push([
          "More neighbors",
          st.k - 7 + " further neighbors included in the computed vote.",
        ]);
    }
    if (lda || qda)
      receipt = [
        ...d.fit.estimates.map((e, i) => [
          "Class " + i,
          "n " +
            e.n +
            " · mean (" +
            fmt(e.mx, 2) +
            ", " +
            fmt(e.mz, 2) +
            ") · prior " +
            fmt(e.prior, 2),
        ]),
        ...d.fit.estimates.map((e, i) => [
          "Σ for class " + i,
          "[[" +
            fmt(e.xx, 3) +
            ", " +
            fmt(e.xz, 3) +
            "], [" +
            fmt(e.xz, 3) +
            ", " +
            fmt(e.zz, 3) +
            "]]",
        ]),
        [
          "Query scores",
          d.fit
            .scores(q)
            .map((x) => fmt(x, 3))
            .join(" versus "),
        ],
      ];
    if (one)
      receipt = [
        ["Selected input", d.fit.key],
        ["Training cut points", d.fit.cuts.map((x) => fmt(x, 3)).join(", ")],
        ...d.fit.values.map((v, i) => [
          "Bin " + (i + 1),
          v.positive + " positive / " + v.n + " rows → class " + v.prediction,
        ]),
        ["Training mistakes", d.fit.errors],
      ];
    if (svm) {
      const margins = d.split.train.map((r) => (r.y ? 1 : -1) * d.score(r));
      receipt = [
        ["Support vectors", d.fit.support.length + " of 48"],
        [
          "Mean training hinge loss",
          fmt(mean(margins.map((m) => Math.max(0, 1 - m))), 4),
        ],
        [
          "Training scaler",
          "μ (" +
            fmt(d.fit.scaler.mx, 2) +
            ", " +
            fmt(d.fit.scaler.mz, 2) +
            ")",
        ],
        [
          "Numerical fit",
          "Bounded deterministic SMO · " + d.fit.iterations + " sweeps",
        ],
        ["Query signed score", fmt(score, 4)],
      ];
      notice +=
        " SVM score is uncalibrated. The bounded solver approximates the soft-margin optimum; support means nonzero dual weight.";
    }
    if (
      scene === "contributions" ||
      (scene === "coefficients" && slug === "logistic-regression")
    )
      receipt = d.fit.weights.map((v, i) => [
        "β" + i,
        fmt(v, 4) + (i ? " · odds multiplier " + fmt(Math.exp(v), 3) : ""),
      ]);
    if (scene === "split")
      receipt = [
        ["Train IDs", d.split.train.map((r) => r.id).join(", ")],
        ["Validation IDs", d.split.validation.map((r) => r.id).join(", ")],
        ["Final test", "16 rows sealed; never used in this view."],
      ];
    if (imb)
      receipt = [
        ["Actual positives / negatives", c.tp + c.fn + " / " + (c.fp + c.tn)],
        ["TP / FN", c.tp + " / " + c.fn],
        ["FP / TN", c.fp + " / " + c.tn],
        ["Alert workload", c.tp + c.fp],
        [
          "Precision",
          precision == null
            ? "Undefined (no alerts)"
            : fmt(precision * 100, 1) + "%",
        ],
      ];
    if (scene === "final" && slug === "logistic-regression")
      receipt = sealed
        ? [
            ["Locked threshold", fmt(sealed.threshold, 2)],
            ["Final-test IDs", sealed.ids.join(", ")],
            [
              "One-time result",
              "TP " +
                sealed.counts.tp +
                " · FP " +
                sealed.counts.fp +
                " · FN " +
                sealed.counts.fn +
                " · TN " +
                sealed.counts.tn,
            ],
            [
              "Status",
              "Controls locked. Reset starts a clearly new development exercise; this is a toy lesson, not fresh independent evidence.",
            ],
          ]
        : [
            [
              "Before revealing",
              "Choose the model and threshold using validation only.",
            ],
            ["Action", "Lock choices & reveal final test."],
            ["Current test status", "Sealed."],
          ];
    L.receipt(L.table(["Inspect", "Value"], receipt));
    L.note(notice);
    L.draw((s, P) => {
      s.begin(310);
      if (scene === "confusion" || scene === "final" || imb) {
        const cc = sealed && scene === "final" ? sealed.counts : c,
          rows = [
            { label: "TP", value: cc.tp, color: palette[2] },
            { label: "FN", value: cc.fn, color: palette[3] },
            { label: "FP", value: cc.fp, color: palette[1] },
            { label: "TN", value: cc.tn, color: palette[0] },
          ];
        bars(s, P, rows);
        s.text(
          "matrix-title",
          15,
          20,
          sealed && scene === "final"
            ? "Final test · choices locked"
            : imb
              ? "10,000-case rate scenario"
              : "Held-out validation counts",
          { "font-size": 16 },
        );
      } else if (scene === "split") {
        flow(
          s,
          P,
          [
            "Split independent units first",
            "48 train: learn every fitted value",
            "16 validation: choose settings",
            "16 test: sealed until choices lock",
          ],
          1,
        );
      } else if (scene === "roc") {
        const a = s.axes(
          [0, 1],
          [0, 1],
          "False-positive rate",
          "True-positive rate",
        );
        s.line("chance", a.x(0), a.y(0), a.x(1), a.y(1), "#aaa", 1, "4 4");
        plotLine(
          s,
          P,
          "roc",
          d.roc.map((r) => [a.x(r.x), a.y(r.y)]),
          palette[2],
          2.5,
        );
        const p = P("operating", a.x(c.fp / (c.fp + c.tn)), a.y(recall));
        s.circle("operating", ...p, 7, palette[1]);
      } else if (
        scene === "sigmoid" ||
        scene === "loss" ||
        scene === "kernel"
      ) {
        const kernel = scene === "kernel",
          loss = scene === "loss",
          a = s.axes(
            kernel
              ? [0, 4]
              : loss
                ? [svm ? -2 : 0.01, svm ? 2 : 0.99]
                : [-6, 6],
            kernel ? [0, 1] : loss ? [0, 5] : [0, 1],
            kernel
              ? "Scaled distance"
              : loss
                ? svm
                  ? "Signed margin"
                  : "Probability of true class"
                : "Linear score z",
            kernel ? "RBF similarity" : loss ? "Loss" : "Probability",
          );
        const xs = linspace(
          kernel ? 0 : loss ? (svm ? -2 : 0.01) : -6,
          kernel ? 4 : loss ? (svm ? 2 : 0.99) : 6,
        );
        plotLine(
          s,
          P,
          "function",
          xs.map((x) => [
            a.x(x),
            a.y(
              kernel
                ? Math.exp(-st.gamma * x * x)
                : loss
                  ? svm
                    ? Math.max(0, 1 - x)
                    : -Math.log(x)
                  : sigmoid(x),
            ),
          ]),
          palette[2],
          2.8,
        );
      } else if (scene === "rules") {
        bars(
          s,
          P,
          d.fit.values.map((r, i) => ({
            label: "Bin " + (i + 1),
            value: r.n ? r.positive / r.n : 0,
            color: palette[i],
          })),
          { domain: 1 },
        );
      } else if (scene === "votes" && knn) {
        bars(
          s,
          P,
          d.fit
            .neighbors(q)
            .slice(0, 5)
            .map((r) => ({ label: r.id, value: r.y, color: palette[r.y] })),
          { domain: 1 },
        );
      } else if (scene === "coefficients" || scene === "contributions") {
        bars(
          s,
          P,
          (
            d.fit.weights || [
              d.fit.estimates?.[0]?.mx || 0,
              d.fit.estimates?.[1]?.mx || 0,
            ]
          ).map((value, i) => ({
            label: d.fit.weights ? "β" + i : "Class " + i + " mean x",
            value,
          })),
        );
      } else {
        const a = s.axes([-3, 3], [-3, 3], "Input x", "Input z");
        if (lda && scene === "projection") {
          const c = d.fit.estimates[0],
            e = d.fit.estimates[1],
            dx = e.mx - c.mx,
            dz = e.mz - c.mz;
          let vx = (c.zz * dx - c.xz * dz) / c.det,
            vz = (c.xx * dz - c.xz * dx) / c.det;
          const norm = Math.hypot(vx, vz) || 1;
          vx /= norm;
          vz /= norm;
          s.line(
            "discriminant-axis",
            a.x(-2.7 * vx),
            a.y(-2.7 * vz),
            a.x(2.7 * vx),
            a.y(2.7 * vz),
            palette[2],
            2.3,
          );
          d.split.train.forEach((r) => {
            const score = r.x * vx + r.z * vz;
            s.line(
              "project-" + r.id,
              a.x(r.x),
              a.y(r.z),
              a.x(score * vx),
              a.y(score * vz),
              palette[r.y] + "55",
              1,
              "3 4",
            );
          });
        }
        const showSurface = ![
          "clouds",
          "means",
          "covariance",
          "projection",
          "distances",
        ].includes(scene);
        if (showSurface)
          d.grid.forEach((r, i) =>
            s.rect(
              "cell" + i,
              a.x(r.x) - 1,
              a.y(r.z) - (a.b - a.t) / 19,
              (a.r - a.l) / 23 + 1,
              (a.b - a.t) / 19 + 1,
              r.score >= st.threshold ? palette[1] + "16" : palette[0] + "16",
            ),
          );
        const neighbors = knn
            ? new Set(d.fit.neighbors(q).map((r) => r.id))
            : new Set(),
          support = svm ? new Set(d.fit.support.map((r) => r.id)) : new Set();
        if (knn && ["neighbors", "distances"].includes(scene))
          d.fit
            .neighbors(q)
            .forEach((r) =>
              s.line(
                "neighbor" + r.id,
                a.x(q.x),
                a.y(q.z),
                a.x(r.x),
                a.y(r.z),
                palette[3] + "70",
                1,
              ),
            );
        if (svm && scene === "margin") {
          const levels = [-1, 0, 1];
          levels.forEach((level, j) => {
            d.grid.forEach((r, i) => {
              if (Math.abs(r.score - level) < 0.15)
                s.circle(
                  "contour" + j + "-" + i,
                  a.x(r.x),
                  a.y(r.z),
                  j === 1 ? 2 : 1.5,
                  j === 1 ? palette[2] : "#817562",
                );
            });
          });
        }
        d.split.train.forEach((r) => {
          const p = P(r.id, a.x(r.x), a.y(r.z));
          s.mark(
            r.id,
            ...p,
            palette[r.y],
            r.id + " class " + r.y,
            neighbors.has(r.id) || support.has(r.id),
            r.id,
          );
        });
        if (lda || qda)
          d.fit.estimates.forEach((e, i) => {
            const p = P("mean" + i, a.x(e.mx), a.y(e.mz));
            s.circle("mean" + i, ...p, 8, "#fffef9", {
              stroke: palette[i],
              "stroke-width": 3,
            });
            if (
              [
                "clouds",
                "covariance",
                "means",
                "projection",
                "distances",
              ].includes(scene)
            ) {
              const l11 = Math.sqrt(e.xx),
                l21 = e.xz / l11,
                l22 = Math.sqrt(Math.max(0, e.zz - l21 * l21)),
                ps = linspace(0, Math.PI * 2, 81).map((t) => [
                  a.x(e.mx + l11 * Math.cos(t)),
                  a.y(e.mz + l21 * Math.cos(t) + l22 * Math.sin(t)),
                ]);
              plotLine(s, P, "ellipse" + i, ps, palette[i], 2);
            }
          });
        const p = P("query", a.x(q.x), a.y(q.z));
        s.circle("query", ...p, 8, palette[3], {
          stroke: "#fffef9",
          "stroke-width": 2,
        });
      }
      s.end(receipt.map((r) => r.join(": ")).join(". "));
    }, animate);
  });
}
function setTextSafe(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}
